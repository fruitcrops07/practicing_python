# Python Module

# a simple module on Python
def printMessage(message):
    print(message)